#include <cstdlib>
#include "Game.h"
using namespace std;

int main() {
    //declares game object
    Game game;

    //calles game class
    game.start();

    return 0;

}

