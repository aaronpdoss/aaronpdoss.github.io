#include "game.h"
#include <iostream>
#include <sstream>

//game constructor
Game::Game() : player("Dungeon") {

    setupRooms();

}

//initializes room map
void Game::setupRooms() {

    Room dungeon("Dungeon");
    dungeon.addDirection("East", "Guardsroom");

    Room guards("Guardsroom");
    guards.addDirection("West", "Dungeon");
    guards.addDirection("South", "Armory");
    guards.addDirection("East", "Entrance");
    guards.setItem("Key");

    Room entrance("Entrance");
    entrance.addDirection("West", "Guardsroom");
    entrance.addDirection("South", "Kitchens");
    entrance.setItem("Map");

    Room kitchens("Kitchens");
    kitchens.addDirection("North", "Entrance");
    kitchens.addDirection("West", "Armory");
    kitchens.setItem("Cat");

    Room armory("Armory");
    armory.addDirection("North", "Guardsroom");
    armory.addDirection("South", "Kings Bedroom");
    armory.addDirection("East", "Kitchens");
    armory.addDirection("West", "Bathroom");
    armory.setItem("Shield");

    Room bathroom("Bathroom");
    bathroom.addDirection("East", "Armory");
    bathroom.setItem("Bottle");

    Room king("Kings Bedroom");
    king.addDirection("North", "Armory");
    king.addDirection("East", "Throne Room");
    king.setItem("Sword");

    Room throne("Throne Room");
    throne.addDirection("West", "Kings Bedroom");
    throne.setBoss("Evil Tyrant");

    // Add to map
    rooms["Dungeon"] = dungeon;
    rooms["Guardsroom"] = guards;
    rooms["Entrance"] = entrance;
    rooms["Kitchens"] = kitchens;
    rooms["Armory"] = armory;
    rooms["Bathroom"] = bathroom;
    rooms["Kings Bedroom"] = king;
    rooms["Throne Room"] = throne;

}

//Main screen text
void Game::showInstructions() const {
    std::cout << "Welcome to the game!\n";
    std::cout << "To move, type 'go' then a direction (North, South, East, West).\n";
    std::cout << "To search the room, type 'grab' and the item name.\n";
    std::cout << "Type 'exit' to quit the game.\n";
}


void Game::start() {

    //calls main screen function
    showInstructions();

    std::string input;

    //gameplay loop
    while (true) {

        std::string currentRoom = player.getCurrentRoom();

        Room& room = rooms[currentRoom];

        //tells player current room
        std::cout << "\nYou are in the " << currentRoom << std::endl;

        //prints inventory
        player.showInventory();

        if (!message.empty()) {

            std::cout << message << std::endl;

        }

        //alert player if room has an item
        if (room.hasItem() && !player.hasItem(room.getItem())) {

            std::cout << "You see a " << room.getItem() << std::endl;

        }

        //alert player if room has boss
        if (room.hasBoss()) {

            std::cout << "You see the " << room.getBoss() << ". TIME TO FIGHT!" << std::endl;

            if (player.inventorySize() == 0) {

                std::cout << "This isn't a speedrun bro. Go find some items!\n";

            }
            //if player has 1 to 5 items, player loses game
            else if (player.inventorySize() > 0 && player.inventorySize() < 6) {

                std::cout << room.getBoss() << " defeated you.\n";

            }
            //if player has 6 or more items, player wins

            else {

                std::cout << "You defeated the " << room.getBoss() << "!\n";

            }
        }

        //user input for move
        std::cout << "\nEnter your move:\n> ";

        std::getline(std::cin, input);

        processInput(input);
    }
}

//process player input
void Game::processInput(const std::string& input) {

    std::stringstream ss(input);

    std::string action;

    ss >> action;

    std::string rest;

    getline(ss, rest);

    std::string argument = rest.empty() ? "" : rest.substr(1); // remove leading space

    std::string argTitle;

    //error handling, forces user input to lower case
    for (auto& ch : argument) {

        ch = std::tolower(ch);

    }

    if (!argument.empty()) {

       argument[0] = std::toupper(argument[0]);

    }

    Room& current = rooms[player.getCurrentRoom()];

    //player chooses to move in a direction
    if (action == "go") {

        std::string next = current.getNextRoom(argument);

        if (!next.empty()) {

            player.setCurrentRoom(next);

            message = "You travel " + argument + ".";

        }
        else {

            message = "You can't go that way.";

        }

    }

    //if player chooses to grab item
    else if (action == "grab") {

        if (current.hasItem() && argument == current.getItem()) {

            if (!player.hasItem(argument)) {

                player.addItem(argument);

                message = argument + " acquired.";

            }
            else {

                message = "You already have the " + argument + ".";

            }
        }

        else {

            message = "Can't find " + argument + ".";

        }

    }

    //player exits game
    else if (action == "exit") {

        std::cout << "Thanks for playing!\n";

        exit(0);

    }

    //player enters invalid command
    else {

        message = "Invalid command.";

    }
}
