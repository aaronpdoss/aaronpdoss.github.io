#include "room.h"

//constructor
Room::Room(std::string name) : name(name), item(""), boss("") {}


    //set item method
    void Room::setItem(const std::string & itemName) {

        item = itemName;

    }

    //set boss method
    void Room::setBoss(const std::string & bossName) {

        boss = bossName;

    }

    //get name method
    std::string Room::getName() const {

        return name;

    }

    //get item method
    std::string Room::getItem() const {

        return item;

    }

    //get boss method
    std::string Room::getBoss() const {

        return boss;

    }

    //checks if room has an item
    bool Room::hasItem() const {

        return !item.empty();

    }

    //checks if room has a boss
    bool Room::hasBoss() const {

        return !boss.empty();

    }

    //adding direction method
    void Room::addDirection(const std::string & dir, const std::string & dest) {

        directions[dir] = dest;

    }

    //gets next room
    std::string Room::getNextRoom(const std::string & direction) const {

        auto it = directions.find(direction);

        if (it != directions.end()) {

            return it->second;

        }

        return "";

    }