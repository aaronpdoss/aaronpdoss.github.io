#include "player.h"
#include <iostream>
#include <algorithm>

//player constructor
Player::Player(const std::string& startRoom): currentRoom(startRoom) {}

//sets current room
void Player::setCurrentRoom(const std::string& roomName) {

    currentRoom = roomName;

}

//gets current room
std::string Player::getCurrentRoom() const {

    return currentRoom;

}

//adds item to inventory
void Player::addItem(const std::string& item) {

    if (!hasItem(item)) {

        inventory.push_back(item);

    }
}

bool Player::hasItem(const std::string& item) const {

    return std::find(inventory.begin(), inventory.end(), item) != inventory.end();

}

size_t Player::inventorySize() const {

    return inventory.size();

}

void Player::showInventory() const {

    std::cout << "Inventory: ";

    for (const auto& item : inventory) {

        std::cout << item << " ";

    }

    std::cout << std::endl;

}
