#pragma once
#include "Room.h"
#include "Player.h"
#include <map>

class Game {

private:

    std::map<std::string, Room> rooms;

    Player player;

    std::string message;

    //initializes rooms method
    void setupRooms();

    //show instructions method
    void showInstructions() const;

    //process player input method
    void processInput(const std::string& input);

public:

    //
    Game();

    void start();

};