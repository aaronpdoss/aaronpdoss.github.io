#pragma once
#include <vector>
#include <string>


class Player {
private:
    std::string currentRoom;
    std::vector<std::string> inventory;

public:
    Player(const std::string& startRoom);

    std::string getCurrentRoom() const;

    void setCurrentRoom(const std::string& roomName);

    void addItem(const std::string& item);

    bool hasItem(const std::string& item) const;

    size_t inventorySize() const;

    void showInventory() const;

};