#pragma once
#include <string>
#include <map>

class Room {

private:

    //private variables
    std::string name;

    std::map<std::string, std::string> directions;

    std::string item;

    std::string boss;

public:

    //constructor
    Room(std::string name);

    //add direction method
    void addDirection(const std::string& dir, const std::string& dest);

    //set item method
    void setItem(const std::string& itemName);

    //set boss method
    void setBoss(const std::string& bossName);

    //get room name method
    std::string getName() const;

    //move to next room method
    std::string getNextRoom(const std::string& direction) const;

    //get item method
    std::string getItem() const;

    //get boss method
    std::string getBoss() const;

    //checks room for items
    bool hasItem() const;

    //checks room for boss
    bool hasBoss() const;

};